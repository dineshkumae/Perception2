/** Automatically generated file. DO NOT MODIFY */
package com.example.perception2k14;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}